#include "Polar_missions.h"
Polar_missions::Polar_missions(int id, int Formulation_Day, int Significance, int Mission_Duration, double Target_Location)
	:Mission(id, Formulation_Day, Significance, Mission_Duration, Target_Location)
{

}