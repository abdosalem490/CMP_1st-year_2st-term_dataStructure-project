#include "MarsStation.h"

#include <iostream>
#include <sstream>
#include <string>



using namespace std;

int main() {

    MarsStation testing;

    char c;
    cin >> c;
    return 0;
}